Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/how-to-import-data-in-mysql-with-codeigniter/

#######################################################

### Instructions - 

* base_url
Rename the folder and edit $config['base_url'] in application/config/config.php

* Database connection
Update database connection in application/config/database.php

* Import attached users.sql file in your database.
